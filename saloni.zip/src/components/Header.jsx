import React from "react";

function Header(){
  return(
    <header>
      <h1> Shape AI Reactjs</h1>
      

    </header>
  );

}
export default Header;